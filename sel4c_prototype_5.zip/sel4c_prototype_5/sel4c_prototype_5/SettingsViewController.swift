//
//  SettingsViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 30/08/23.
//

import UIKit

class SettingsViewController: UIViewController {

    @IBOutlet weak var perfilButton: UIButton!
    
    @IBOutlet weak var contactButton: UIButton!
    
    @IBOutlet weak var avisoButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        perfilButton.setTitleColor(UIColor.gray, for: UIControl.State.normal)
        perfilButton.layer.borderWidth = 1
        perfilButton.layer.borderColor = UIColor.black.cgColor
        
        contactButton.setTitleColor(UIColor.gray, for: UIControl.State.normal)
        contactButton.layer.borderWidth = 1
        contactButton.layer.borderColor = UIColor.black.cgColor
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
