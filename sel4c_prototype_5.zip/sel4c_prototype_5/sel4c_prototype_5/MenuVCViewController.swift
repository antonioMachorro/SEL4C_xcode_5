//
//  MenuVCViewController.swift
//  sel4c_prototype_5
//
//  Created by Roberto Machorro on 30/08/23.
//

import UIKit

class MenuVCViewController: UIViewController {

    @IBOutlet weak var buttonNivel: UIButton!
    
    @IBOutlet weak var buttonConfig: UIButton!
    
    @IBOutlet weak var actButtons: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setPupopButton()
        
        self.navigationItem.hidesBackButton = true
        aprendizajeView.layer.borderWidth = 2
        aprendizajeView.layer.borderColor = UIColor.black.cgColor
        cuestionariosViews.layer.borderWidth = 2
        cuestionariosViews.layer.borderColor = UIColor.black.cgColor
        entregablesViews.layer.borderWidth = 2
        entregablesViews.layer.borderColor = UIColor.black.cgColor
        
        buttonNivel.layer.borderWidth = 1
        buttonNivel.layer.borderColor = UIColor.white.cgColor
        buttonConfig.layer.borderWidth = 1
        buttonConfig.layer.borderColor = UIColor.white.cgColor
    }
    
    func setPupopButton(){
        let optionClosure = {(action : UIAction) in
            print(action.title)}
        
        actButtons.menu = UIMenu(children : [
            UIAction(title : "Actividad 1", state : .on, handler: optionClosure),
            UIAction(title : "Actividad 2", state : .on, handler: optionClosure),
            UIAction(title : "Actividad 3", state : .on, handler: optionClosure),
            UIAction(title : "Actividad 4", state : .on, handler: optionClosure),
            UIAction(title : "Entrega Final", state : .on, handler: optionClosure)])
        actButtons.showsMenuAsPrimaryAction = true
        actButtons.changesSelectionAsPrimaryAction = true
    }
    
    @IBOutlet weak var aprendizajeView: UIView!

    @IBOutlet weak var cuestionariosViews: UIView!
    
    @IBOutlet weak var entregablesViews: UIView!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
